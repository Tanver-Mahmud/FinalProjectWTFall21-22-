<?php 
//storing data into the session.................
session_start();
require_once "../model/config.php";
//featching data from the Login from 
if (isset($_POST['submit'])) {
    $username = $_POST['email'];
    $password = $_POST['password'];
//Use of cookie to store login credantial into borowser.

    $time = time();
    if (isset($_POST['rmbm'])) {
        setcookie('email', $username, $time + 10);
        setcookie('password', $password, $time + 10);
    }

  //featching data from the data base to check with the user input  
    $select = mysqli_query($dbh,"SELECT * FROM `login` WHERE `email`='$username' and `password`='$password'");
    

    if (mysqli_num_rows($select)>0) {

        $ftch = mysqli_fetch_assoc($select);

        if ($ftch['email'] == $username && $ftch['password']==$password) {
            
            
            $_SESSION['email'] = $ftch['email'];
            $_SESSION['name'] = $ftch['name'];

         

if(($ftch['status'])=="Manager")
{
    header("Location:../public/view/Manager/mdashboard.php");
    
}


if(($ftch['status'])=="Stuff")
{
    header("Location:../public/view/Stuff/sdashboard.php");
    
}




if(($ftch['status'])=="Admin")
{
    header("Location:../public/view/Admin/adashboard.php");
    
}

if(($ftch['status'])=="customer")
{
    header("Location:../public/view/Customer/cdashboard.php");
    
}





            
}
        
        else{
            header("Location:login.php");
        }
    
    }
}

?>

