
<?php
//connect to DB



require_once('../public/view//include/conn.php');


//Flash Message
$message="";
if(isset($dbh)){
//connection check
if(isset($_POST['submit'])){



$stmt = $dbh->prepare("INSERT INTO `reservation`(`name`,`phone`,`occation`,`branch_name`,`email`,`food_package`,`number_of_person`,`date`,`time`,`address`) VALUES (:name, :number, :occation, :branch, :email, :food, :person, :date, :time, :address)");


    


$stmt->bindParam(':name', $name);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':person', $person);
$stmt->bindParam(':branch', $branch);
$stmt->bindParam(':number', $number);

$stmt->bindParam(':food', $food);
$stmt->bindParam(':date', $date);
$stmt->bindParam(':time', $time);
$stmt->bindParam(':address', $address);
$stmt->bindParam(':occation', $occation);

//insert File

//Fatch data user form


$name = $_POST['name'];
$email = $_POST['email'];
$person = $_POST['person'];
$branch = $_POST['branch'];
$number=$_POST['number'];
$food=$_POST['food'];
$date = $_POST['date'];
$time=$_POST['time'];
$address=$_POST['address'];
$occation = $_POST['occation'];




//check name 


  //execute Query1
  if($stmt->execute()){
       $message="Insert Row Scuccess";
 header("location:index.php");
    }
    else{
      $message="Insert Row Fail";
    }

}

}



?>