<?php
require_once "../model/config.php";

if (isset($_POST['submit'])) {

    $username = $_POST['email'];
    $password = $_POST['password'];



    $update = mysqli_query($dbh,"UPDATE `stuff` SET `PASSWORD`='$password' WHERE `email`='$username'");
    if($update){

        header('location:../public/view/Stuff/schangePassword.php');
    }
else{
    echo "Password reset Failed";
}


$update1 = mysqli_query($dbh,"UPDATE `login` SET `password`='$password' WHERE `email`='$username'");
if($update1){

    header('location:../public/view/Stuff/schangePassword.php');
}
else{
echo "Password reset Failed";
}


}
?>