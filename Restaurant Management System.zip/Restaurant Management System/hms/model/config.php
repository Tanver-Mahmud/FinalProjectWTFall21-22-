<?php
$dbh = mysqli_connect('localhost','root','','hms');
?>
