-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2021 at 05:46 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `picture` varchar(30) DEFAULT NULL,
  `salary` varchar(30) DEFAULT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `phone`, `address`, `age`, `email`, `picture`, `salary`, `PASSWORD`) VALUES
(1, 'Nahian', '01469949867', 'dhaka', 22, 'nahian@gmail.com', '../assets/img/user/252247331_3', NULL, '123123');

-- --------------------------------------------------------

--
-- Table structure for table `approve_reservation`
--

CREATE TABLE `approve_reservation` (
  `id` int(11) NOT NULL,
  `table_number` varchar(30) NOT NULL,
  `date` varchar(20) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `branch_name` varchar(50) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `manager` varchar(50) DEFAULT NULL,
  `food_package` varchar(20) DEFAULT NULL,
  `number_of_person` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product` varchar(30) NOT NULL,
  `product_id` varchar(14) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `branch_name` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `quantity` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `picture` varchar(30) DEFAULT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `phone`, `address`, `age`, `email`, `picture`, `PASSWORD`) VALUES
(1, 'Nahin', '01303067684', 'Dhaka', NULL, 'nahin@gmail.com', 'assets/img/user/5.jpg', '123123'),
(2, 'Mohim', '01303064653', '22', 123123, 'mohim@gmail.com', 'assets/img/user/252247331_3179', 'Dhaka'),
(3, 'Nabil', '01303064653', 'dhaka', 22, 'nabil@gmail.com', 'assets/img/user/252247331_3179', '123123'),
(4, 'Motaleb', '01303064681', 'dhaka', 21, 'motaleb@gmail.com', 'assets/img/user/252247331_3179', '123123'),
(5, 'Forhad', '01306065682', 'dhaka', 20, 'forhad@gmail.com', 'assets/img/user/252247331_3179', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `salay` int(7) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `status`, `password`) VALUES
(2, 'tuhin', 'tuhin@gmail.com', 'Manager', '123123'),
(5, 'Nahian', 'nahian@gmail.com', 'Admin', '123123'),
(7, 'Tahsan', 'tahsan@gmail.com', 'Stuff', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `manger`
--

CREATE TABLE `manger` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `address` varchar(14) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL,
  `image` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `manger`
--

INSERT INTO `manger` (`id`, `name`, `phone`, `address`, `age`, `email`, `PASSWORD`, `image`) VALUES
(7, 'hasan', '1616516161', 'dhaka', 20, 'hasan@gmail.com', '123123', ''),
(8, 'Ahmed', '01303064682', 'Dhaka', 25, 'ahmed@gmaill.com', '123123', ''),
(9, 'Printhu', '016303030', 'dhaka', 23, 'printhu', '123123', ''),
(16, 'Abdullah', '0190985656', 'dhaka', 25, 'abdullah@gmail.com', '1122233', ''),
(17, 'Khairul', '2616161', 'dhaka', 22, 'kahairul@gmail.com', '112233', ''),
(18, 'khair', '515616', 'dhaka', 33, 'khair@gmail.com', '123123', ''),
(19, 'Nabi', '161616', 'dhaka', 30, 'nabi@gmail.com', '123123', ''),
(24, 'aumlan', '1616161', 'dhaka', 23, 'aumlan@gmail.com', '123123', ''),
(25, 'naim', '516161', 'dhaka', 22, 'naim@gmail.com', '123123', ''),
(41, 'Tasmia ', '01612287375', 'Dhaka', 24, 'tasmia@gmail.com', '123123', ''),
(61, 'maria', '01202064689', 'feni', 20, 'maria@gmail.com', '121212', '../assets/img/user/252247331_3');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `image` varchar(30) NOT NULL,
  `date` varchar(25) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `branch_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `date` varchar(15) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `image` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `product_id`, `pname`, `address`, `quantity`, `phone`, `email`, `date`, `time`, `image`, `status`) VALUES
(1, '', '1', 'kuril dhaka', '1', '01869949823', '', '10/12/2021', '10.55 pm', '', 'panding');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `branch_name` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `menu_id` varchar(255) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `branch_name`, `image`, `price`, `menu_id`, `date`) VALUES
(1, 'adfasd', 'asdfasd', '../assets/img/user/burger.jpg', 'asdfasd', 'asdfs', 'Dec 06 2021'),
(6, 'Pizza', 'Uttara', '../assets/img/user/5-removebg-preview.png', '450', '1', 'Dec 06 2021'),
(10, 'Sweet', 'Uttara', '../assets/img/user/demo1.png', '450', '1', 'Dec 06 2021');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `address` varchar(50) NOT NULL,
  `occation` varchar(20) DEFAULT NULL,
  `branch_name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `food_package` varchar(20) DEFAULT NULL,
  `number_of_person` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL,
  `time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`id`, `name`, `phone`, `address`, `occation`, `branch_name`, `email`, `food_package`, `number_of_person`, `date`, `time`) VALUES
(1, 'Nadim', '01869949823', 'Uttara', 'Birthday Party', 'Uttara', 'nadim@gmail.com', 'Burger and Pizza', '5', '2021-03-22', '11:20'),
(2, 'Mohim', '01869949725', 'Uttara', 'Birthday Party', 'Uttara', 'mohim@gmail.com', 'Burger and Pizza', '6', '2021-03-22', '11:20'),
(3, 'ador', '013030364786', 'Dhanmondi', 'Birthday Party', 'Uttara', 'ador@gmail.com', 'Burger and Pizza', '6', '2021-06-07', '14:50'),
(4, 'Tuhin', '01589111222', 'Uttara', 'Birthday Party', 'Uttara', 'tuhin@gmail.com', 'Burger and Pizza', '9', '2021-02-05', '14:05'),
(5, 'Rasel ', '01838179772', 'Uttara', 'Birthday Party', 'Uttara', 'rasel@gmail.com', 'Burger and Pizza', '6', '2021-01-02', '02:10'),
(6, 'Motaleb', '01869121212', 'dhaka', 'Birthday Party', 'Uttara', 'motaleb@gmail.com', 'Burger and Pizza', '10', '2021-10-10', '05:06');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `text` varchar(200) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `iteam_name` varchar(30) NOT NULL,
  `branch_name` varchar(50) DEFAULT NULL,
  `quantity` varchar(20) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  `date` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `stuff`
--

CREATE TABLE `stuff` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `picture` varchar(30) DEFAULT NULL,
  `salary` varchar(30) DEFAULT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stuff`
--

INSERT INTO `stuff` (`id`, `name`, `phone`, `address`, `age`, `email`, `picture`, `salary`, `PASSWORD`) VALUES
(1, 'Niloy', '01869222111', 'dhaka', 30, 'niloy@gmail.com', '../assets/img/user/5.jpg', NULL, '010101');

-- --------------------------------------------------------

--
-- Table structure for table `support`
--

CREATE TABLE `support` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `address` varchar(14) DEFAULT NULL,
  `email` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `CustomerID` int(11) NOT NULL,
  `CustomerName` varchar(250) NOT NULL,
  `Address` text NOT NULL,
  `City` varchar(250) NOT NULL,
  `PostalCode` varchar(30) NOT NULL,
  `Country` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`CustomerID`, `CustomerName`, `Address`, `City`, `PostalCode`, `Country`) VALUES
(1, 'Maria Anders', 'Obere Str. 57', 'Berlin', '12209', 'Germany'),
(2, 'Ana Trujillo', 'Avda. de la Construction 2222', 'Mexico D.F.', '5021', 'Mexico'),
(3, 'Antonio Moreno', 'Mataderos 2312', 'Mexico D.F.', '5023', 'Mexico'),
(4, 'Thomas Hardy', '120 Hanover Sq.', 'London', 'WA1 1DP', 'UK'),
(5, 'Paula Parente', 'Rua do Mercado, 12', 'Resende', '08737-363', 'Brazil'),
(6, 'Wolski Zbyszek', 'ul. Filtrowa 68', 'Walla', '01-012', 'Poland'),
(7, 'Matti Karttunen', 'Keskuskatu 45', 'Helsinki', '21240', 'Finland'),
(8, 'Karl Jablonski', '305 - 14th Ave. S. Suite 3B', 'Seattle', '98128', 'USA'),
(9, 'Paula Parente', 'Rua do Mercado, 12', 'Resende', '08737-363', 'Brazil'),
(10, 'Pirkko Koskitalo', 'Torikatu 38', 'Oulu', '90110', 'Finland');

-- --------------------------------------------------------

--
-- Table structure for table `waiter`
--

CREATE TABLE `waiter` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone` varchar(14) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `picture` varchar(30) DEFAULT NULL,
  `salary` varchar(30) DEFAULT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `approve_reservation`
--
ALTER TABLE `approve_reservation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`),
  ADD UNIQUE KEY `image` (`image`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `eamil` (`email`);

--
-- Indexes for table `manger`
--
ALTER TABLE `manger`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `image` (`image`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stuff`
--
ALTER TABLE `stuff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support`
--
ALTER TABLE `support`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `waiter`
--
ALTER TABLE `waiter`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `approve_reservation`
--
ALTER TABLE `approve_reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `manger`
--
ALTER TABLE `manger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stuff`
--
ALTER TABLE `stuff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `support`
--
ALTER TABLE `support`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `waiter`
--
ALTER TABLE `waiter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
