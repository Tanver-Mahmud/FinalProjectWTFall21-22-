<?php

include('include/nav.php');
?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="stylesheet" type="text/css" href="assets/css/custom.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

<!------ Include the above in your HEAD tag ---------->
<link rel="stylesheet" href="login.css">
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
   <H1>Order confirmation</H1>
</br>
    </div>

    <!-- Login Form -->
    <form  action="../../controller/orderContorller.php" method="post">


    <img style="width:250px; hight:250px" src="images/g-1.jpg">
    <br>
    </br>
    <div class="row text-left pl-2">

    <div class="col-lg-8">
      <label><h3>Product Code</h3></label>
    </div>

    <div class="col-lg-4">
    <label><h3>h23</h3></label>
    </div>
    </div>

    <div class="row text-left pl-2">

<div class="col-lg-8">
  <label><h3>Product Price</h3></label>
</div>

<div class="col-lg-4">
<input type="text" id="price" class="fadeIn second" name="price" placeholder="">
</div>
</div>


<div class="row text-left pl-2">

<div class="col-lg-8">
  <label><h3>Product Quantiry</h3></label>
</div>

<div class="col-lg-4">
<input type="number" id="quantity" class="fadeIn second" name="quantity" placeholder="">
</div>
</div>




      <input type="number" id="eamil" class="fadeIn second" name="email" placeholder="Enter your Email ">




      <input type="text" id="password" class="fadeIn third" name="password" 

        
        <br/>
      <input type="submit" name="submit"class="fadeIn fourth" value="Order">


    </form>

    <!-- Remind Passowrd -->
  

  </div>
</div>