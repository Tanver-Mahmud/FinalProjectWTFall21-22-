<?php
unlink("delete.txt");

?>