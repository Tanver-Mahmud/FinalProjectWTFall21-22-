
<?php
//connect to DB



require_once('../include/conn.php');


//Flash Message
$message="";
if(isset($dbh)){
//connection check
if(isset($_POST['submit'])){



$stmt = $dbh->prepare("INSERT INTO `menu`(`name`,`branch_name`,`image`,`date`) VALUES (:name, :branch, :price, :image, :date)");


$stmt->bindParam(':name', $name);
$stmt->bindParam(':branch', $branch);

$stmt->bindParam(':date', $date);
$stmt->bindParam(':image', $image);


//insert File
$target_dir = "../assets/img/user/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
//Fatch data user form



if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
$name = $_POST['name'];
$branch = $_POST['branch'];
$price = $_POST['price'];
$menuid = $_POST['menuid'];
$image = $target_file;
$date = date("M d Y");





//check name 


  //execute Query1
  if($stmt->execute()){
       $message="Insert Row Scuccess";
 // header("Location:addFood.php");
    }
    else{
      $message="Insert Row Fail";
    }

}

}
else{
  $message="You file is not an image!";
 // header("Location:addFood.php");
 
}
}

?>


<!-- Sidebar Start from here -->
  <?php
  include_once('sidebar.php');
  ?>
<!-- sidebar end at here -->




<body>
    <section class="material-half-bg">
      <div class="cover"></div>
    </section>
    <section class="login-content">
      <div class="logo">
        
      </div>
      <div class="login-box2">
        <!-- <form action="" method="post" enctype="multipart/form-data"> -->
          
       
        <form action="addFood.php" name="myform" method="post" class="login-form" enctype="multipart/form-data" onsubmit="validateform()">
          <h3 class="login-head"><i class="fa fa-lg fa-fw fa-users"></i> Add Menu</h3>


           <div class="message text-danger"><?php if($message!="") { echo $message; } ?></div>




          <div class="form-group">
            <label class="control-label text-dark"">Product Name <span class="text-danger">*</span></label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Name" autocomplete="off" onkeyup="checkName()" onblur="checkName()"> 
            <span id="nameErr"></span>
          </div>



          <div class="form-group">
            <label class="control-label text-dark"">Branch Name <span class="text-danger">*</span></label>
            <input type="text" name="branch" id="branch" class="form-control" placeholder="Branch Name" autocomplete="off" onkeyup="checkBranch()" onblur="checkBranch()">
              <span id="branchErr"></span>
          </div>

         
        
      
          <div class="form-group">
            <label class="control-label text-dark">Image <span class="text-danger">*</span></label>
            <input type="file" name="image" id="" class="form-control">
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary btn-block" type="submit" name="submit" value="submit"><i class="fa fa-sign-in fa-lg fa-fw"></i>Add Product</button>

            <!-- <button class="btn btn-primary btn-block" type="reset" <i class="fa fa-sign-in fa-lg fa-fw"></i>Reset</button> -->
          </div>
           

        </form>
        
      </div>


 <!-- Essential javascripts for application to work-->
 <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="assets/js/plugins/pace.min.js"></script>


    <script>
      $(document).ready(function(){
        $('#password, #confirmpassword').on('keyup', function () {
          if ($('#password').val() == $('#confirmpassword').val()) {

            $('#message').html('Matching').css('color', 'green');

          }
          else
            $('#message').html('Not Matching').css('color', 'red');
        });
      });
    </script>

    <!-- JS Validation Start -->

    <script>  

    function validateform(){  
    var name=document.myform.name.value;
    var branch=document.myform.age.value;
    var price=document.myform.email.value;
    var menuid=document.myform.mobile.value;
   
      
    if (name==null || name==""){  
      alert("Name can't be Empty");  
      return false;  
    }else if (branch==null || branch=="") {
      alert("Branch can't be Empty");
      return false;  
    }

 
    }
    function checkEmpty() {
        if (document.myform.name.value = "") {
          alert("Name can't be Empty");
            return false;  
        }
      }  

      
    function checkName() {
        if (document.getElementById("name").value == "") {
            document.getElementById("nameErr").innerHTML = "Name can't be blank";
            document.getElementById("nameErr").style.color = "red";
            document.getElementById("name").style.borderColor = "red";
        } else {
            document.getElementById("nameErr").innerHTML = "";
            document.getElementById("name").style.borderColor = "green";
        }
    }


      
        
        function checkBranch() {
        if (document.getElementById("branch").value == "") {
            document.getElementById("branchErr").innerHTML = "Branch Name can't be blank";
            document.getElementById("branchErr").style.color = "red";
            document.getElementById("branch").style.borderColor = "red";
        }else{
            document.getElementById("branchErr").innerHTML = "";
            document.getElementById("branch").style.borderColor = "green";
        }




    }

    
       
        
</script>  
    <!-- JS Validation End -->



    <!-- Essential javascripts for application to work-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="js/plugins/pace.min.js"></script>
    <!-- Page specific javascripts-->
    <!-- Google analytics script-->
    <script type="text/javascript">
      if(document.location.hostname == 'pratikborsadiya.in') {
      	(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      	})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
      	ga('create', 'UA-72504830-1', 'auto');
      	ga('send', 'pageview');
      }
    </script>
  </body>
</html>


