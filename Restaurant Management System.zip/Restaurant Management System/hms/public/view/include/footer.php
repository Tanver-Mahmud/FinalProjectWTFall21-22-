<!-- Essential javascripts for application to work-->
    <script src="../ledp-lms/assets/js/jquery-3.3.1.min.js"></script>
    <script src="../ledp-lms/assets/js/popper.min.js"></script>
    <script src="../ledp-lms/assets/js/bootstrap.min.js"></script>
    <script src="../ledp-lms/assets/js/main.js"></script>
    <!-- The javascript plugin to display page loading on top-->
    <script src="../ledp-lms/assets/js/plugins/pace.min.js"></script>
    <!-- Data table plugin-->
    <script type="text/javascript" src="../ledp-lms/assets/js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../ledp-lms/assets/js/plugins/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
    
  </body>
</html>