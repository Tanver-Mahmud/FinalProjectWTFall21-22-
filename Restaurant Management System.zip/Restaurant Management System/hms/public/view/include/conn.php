<?php
$dsn="mysql:host=localhost;dbname=hms";
$user="root";
$pass="";
$dbh = new PDO($dsn,$user,$pass);
