


<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="assets/css/Style.css">


</head>
<body>
	<div class="navsize">
	<header>
	<a href="home.php"><img class="logo" src="assets/img/logo.jpg" alt=""></a>

	<nav>
		<ul class="navlink">
			<li><a href="../view/index.php" title=""> Home </a></li>
			<li> | </li>
			<li><a href="login.php" title="">Login </a></li>
			<li> | </li>
			<li><a href="register.php" title="">Registration</a></li>
		</ul>
	</nav>
	</header> <!-- /header -->
    </div>

</body>
</html>