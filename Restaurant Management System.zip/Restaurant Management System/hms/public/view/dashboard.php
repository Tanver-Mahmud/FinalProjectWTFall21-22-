<h1>Welcome to Dahsboard</h1>
<a href="register.php" style="padding-left:170px ">Logout</a>