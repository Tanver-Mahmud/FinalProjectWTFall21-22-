
<?php
session_start();
require_once "../../../model/config.php";


$id = $_GET['id'];



$que = mysqli_query($dbh,"DELETE  FROM `stuff` WHERE `id`='$id'");

$que1 = mysqli_query($dbh,"DELETE  FROM `login` WHERE `id`='$id'");


header('location:searchStuff.php');

?>

?>