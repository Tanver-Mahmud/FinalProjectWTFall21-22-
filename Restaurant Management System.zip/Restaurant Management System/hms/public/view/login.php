<?php

include('include/nav.php');
?>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="stylesheet" type="text/css" href="assets/css/custom.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

<!------ Include the above in your HEAD tag ---------->
<link rel="stylesheet" href="login.css">
<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
    <h3 style="font-weight: 700;">Login</h3>
    </div>

    <!-- Login Form -->
    <form  action="../../controller/loginController.php" method="post">
      <input type="text" id="eamil" class="fadeIn second" name="email" placeholder="Enter your Email ">
      <input type="text" id="password" class="fadeIn third" name="password" placeholder="Enter your Password">
<br/>
      <input type="checkbox" id="rmbm" name="rmbm" value="True">
        <label for="rmbm"> Remember Me</label>
        <br/>
      <input type="submit" name="submit"class="fadeIn fourth" value="Log In">


    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      
      <a class="underlineHover" href="register.php">Create Account</a>
    </div>

  </div>
</div>